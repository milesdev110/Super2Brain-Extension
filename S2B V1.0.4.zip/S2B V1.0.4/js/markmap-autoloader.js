/**
 * Minified by jsDelivr using Terser v5.19.2.
 * Original file: /npm/markmap-autoloader@0.17.0/dist/index.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
(this.markmap = this.markmap || {}),
  (function (e) {
    "use strict";
    var t;
    const r = {
      jsdelivr: (e) => `https://cdn.jsdelivr.net/npm/${e}`,
      unpkg: (e) => `https://unpkg.com/${e}`,
    };
    const n = new (class {
      constructor() {
        (this.providers = { ...r }), (this.provider = "jsdelivr");
      }
      async getFastestProvider(e = 5e3, t = "npm2url/dist/index.cjs") {
        const r = new AbortController();
        let n = 0;
        try {
          return await new Promise((o, a) => {
            Promise.all(
              Object.entries(this.providers).map(async ([e, n]) => {
                try {
                  await (async function (e, t) {
                    const r = await fetch(e, { signal: t });
                    if (!r.ok) throw r;
                    await r.text();
                  })(n(t), r.signal),
                    o(e);
                } catch {}
              })
            ).then(() => a(new Error("All providers failed"))),
              (n = setTimeout(a, e, new Error("Timed out")));
          });
        } finally {
          r.abort(), clearTimeout(n);
        }
      }
      async findFastestProvider(e, t) {
        return (
          (this.provider = await this.getFastestProvider(e, t)), this.provider
        );
      }
      setProvider(e, t) {
        t ? (this.providers[e] = t) : delete this.providers[e];
      }
      getFullUrl(e, t = this.provider) {
        if (e.includes("://")) return e;
        const r = this.providers[t];
        if (!r) throw new Error(`Provider ${t} not found`);
        return r(e);
      }
    })();
    function o() {
      const e = {};
      return (
        (e.promise = new Promise((t, r) => {
          (e.resolve = t), (e.reject = r);
        })),
        e
      );
    }
    Math.random().toString(36).slice(2, 8);
    /*! @gera2ld/jsx-dom v2.2.2 | ISC License */
    const a = 1,
      s = 2,
      i = "http://www.w3.org/2000/svg",
      l = "http://www.w3.org/1999/xlink",
      c = { show: l, actuate: l, href: l },
      d = (e) => "string" == typeof e || "number" == typeof e,
      u = (e) => (null == e ? void 0 : e.vtype) === a,
      p = (e) => (null == e ? void 0 : e.vtype) === s;
    function f(e, t, ...r) {
      return (function (e, t) {
        let r;
        if ("string" == typeof e) r = a;
        else {
          if ("function" != typeof e) throw new Error("Invalid VNode type");
          r = s;
        }
        return { vtype: r, type: e, props: t };
      })(
        e,
        (t = Object.assign({}, t, { children: 1 === r.length ? r[0] : r }))
      );
    }
    function m(e) {
      return e.children;
    }
    const v = { isSvg: !1 };
    function h(e, t) {
      Array.isArray(t) || (t = [t]),
        (t = t.filter(Boolean)).length && e.append(...t);
    }
    const y = { className: "class", labelFor: "for" };
    function g(e, t, r, n) {
      if (((t = y[t] || t), !0 === r)) e.setAttribute(t, "");
      else if (!1 === r) e.removeAttribute(t);
      else {
        const o = n ? c[t] : void 0;
        void 0 !== o ? e.setAttributeNS(o, t, r) : e.setAttribute(t, r);
      }
    }
    function w(e, t) {
      return Array.isArray(e)
        ? e.map((e) => w(e, t)).reduce((e, t) => e.concat(t), [])
        : b(e, t);
    }
    function b(e, t = v) {
      if (null == e || "boolean" == typeof e) return null;
      if (e instanceof Node) return e;
      if (p(e)) {
        const { type: r, props: n } = e;
        if (r === m) {
          const e = document.createDocumentFragment();
          if (n.children) {
            h(e, w(n.children, t));
          }
          return e;
        }
        return b(r(n), t);
      }
      if (d(e)) return document.createTextNode(`${e}`);
      if (u(e)) {
        let r;
        const { type: n, props: o } = e;
        if (
          (t.isSvg || "svg" !== n || (t = Object.assign({}, t, { isSvg: !0 })),
          (r = t.isSvg
            ? document.createElementNS(i, n)
            : document.createElement(n)),
          (function (e, t, r) {
            for (const n in t)
              if ("key" !== n && "children" !== n && "ref" !== n)
                if ("dangerouslySetInnerHTML" === n) e.innerHTML = t[n].__html;
                else if (
                  "innerHTML" === n ||
                  "textContent" === n ||
                  "innerText" === n ||
                  ("value" === n && ["textarea", "select"].includes(e.tagName))
                ) {
                  const r = t[n];
                  null != r && (e[n] = r);
                } else
                  n.startsWith("on")
                    ? (e[n.toLowerCase()] = t[n])
                    : g(e, n, t[n], r.isSvg);
          })(r, o, t),
          o.children)
        ) {
          let e = t;
          t.isSvg &&
            "foreignObject" === n &&
            (e = Object.assign({}, e, { isSvg: !1 }));
          const a = w(o.children, e);
          null != a && h(r, a);
        }
        const { ref: a } = o;
        return "function" == typeof a && a(r), r;
      }
      throw new Error("mount: Invalid Vnode!");
    }
    function k(...e) {
      return b(f(...e));
    }
    const S = (function (e) {
        const t = {};
        return function (...r) {
          const n = `${r[0]}`;
          let o = t[n];
          return o || ((o = { value: e(...r) }), (t[n] = o)), o.value;
        };
      })((e) => {
        document.head.append(
          k("link", { rel: "preload", as: "script", href: e })
        );
      }),
      j = {},
      P = {};
    async function A(e, t) {
      var r;
      const n =
        ("script" === e.type && (null == (r = e.data) ? void 0 : r.src)) || "";
      if ((e.loaded || (e.loaded = j[n]), !e.loaded)) {
        const r = o();
        if (
          ((e.loaded = r.promise),
          "script" === e.type &&
            (document.head.append(
              k("script", {
                ...e.data,
                onLoad: () => r.resolve(),
                onError: r.reject,
              })
            ),
            n ? (j[n] = e.loaded) : r.resolve()),
          "iife" === e.type)
        ) {
          const { fn: n, getParams: o } = e.data;
          n(...((null == o ? void 0 : o(t)) || [])), r.resolve();
        }
      }
      await e.loaded;
    }
    async function E(e, t) {
      e.forEach((e) => {
        var t;
        "script" === e.type &&
          (null == (t = e.data) ? void 0 : t.src) &&
          S(e.data.src);
      }),
        (t = { getMarkmap: () => window.markmap, ...t });
      for (const r of e) await A(r, t);
    }
    async function x(e) {
      await Promise.all(
        e.map((e) =>
          (async function (e) {
            const t = ("stylesheet" === e.type && e.data.href) || "";
            if ((e.loaded || (e.loaded = P[t]), !e.loaded)) {
              const r = o();
              (e.loaded = r.promise),
                t && (P[t] = e.loaded),
                "style" === e.type
                  ? (document.head.append(k("style", { textContent: e.data })),
                    r.resolve())
                  : t &&
                    (document.head.append(
                      k("link", { rel: "stylesheet", ...e.data })
                    ),
                    fetch(t)
                      .then((e) => {
                        if (e.ok) return e.text();
                        throw e;
                      })
                      .then(() => r.resolve(), r.reject));
            }
            await e.loaded;
          })(e)
        )
      );
    }
    const C = {},
      L = {
        baseJs: [
          "d3@7.8.5",
          "markmap-lib@0.17.0",
          "markmap-view@0.17.0",
          "markmap-toolbar@0.17.0",
        ],
        baseCss: ["markmap-toolbar@0.17.0/dist/style.css"],
        manual: !1,
        toolbar: !1,
        ...(null == (t = window.markmap) ? void 0 : t.autoLoader),
      };
    const T = (async function () {
      var e;
      if ("function" == typeof L.provider)
        n.setProvider((n.provider = "autoLoader"), L.provider);
      else if ("string" == typeof L.provider) n.provider = L.provider;
      else
        try {
          await n.findFastestProvider();
        } catch {}
      await Promise.all([
        E(
          L.baseJs.map((e) =>
            "string" == typeof e
              ? { type: "script", data: { src: n.getFullUrl(e) } }
              : e
          )
        ),
        x(
          L.baseCss.map((e) =>
            "string" == typeof e
              ? { type: "stylesheet", data: { href: n.getFullUrl(e) } }
              : e
          )
        ),
      ]);
      const { markmap: t } = window,
        r = document.createElement("style");
      (r.textContent = t.globalCSS),
        document.body.prepend(r),
        null == (e = L.onReady) || e.call(L);
    })();
    function M(e) {
      var t;
      const {
          Transformer: r,
          Markmap: o,
          deriveOptions: a,
          Toolbar: s,
        } = window.markmap,
        i = (null == (t = e.textContent) ? void 0 : t.split("\n")) || [];
      let l = 1 / 0;
      i.forEach((e) => {
        var t;
        const r = (null == (t = e.match(/^\s*/)) ? void 0 : t[0].length) || 0;
        r < e.length && (l = Math.min(l, r));
      });
      const c = i
          .map((e) => e.slice(l))
          .join("\n")
          .trim(),
        d = new r(L.transformPlugins);
      (d.urlBuilder = n), (e.innerHTML = "<svg></svg>");
      const u = e.firstChild,
        p = o.create(u, { embedGlobalCSS: !1 });
      if (L.toolbar) {
        const { el: t } = s.create(p);
        Object.assign(t.style, {
          position: "absolute",
          right: "20px",
          bottom: "20px",
        }),
          e.append(t);
      }
      const f = () => {
        const { root: e, frontmatter: t } = (function (e, t) {
            const r = e.transform(t),
              n = Object.keys(r.features).filter((e) => !C[e]);
            n.forEach((e) => {
              C[e] = !0;
            });
            const { styles: o, scripts: a } = e.getAssets(n),
              { markmap: s } = window;
            return o && s.loadCSS(o), a && s.loadJS(a), r;
          })(d, c),
          r = null == t ? void 0 : t.markmap,
          n = a(r);
        p.setData(e, n), p.fit();
      };
      d.hooks.retransform.tap(f), f();
    }
    async function O(e) {
      await T, e.querySelectorAll(".markmap").forEach(M);
    }
    function F() {
      return O(document);
    }
    L.manual ||
      ("loading" === document.readyState
        ? document.addEventListener("DOMContentLoaded", () => {
            F();
          })
        : F()),
      (e.ready = T),
      (e.render = M),
      (e.renderAll = F),
      (e.renderAllUnder = O),
      Object.defineProperty(e, Symbol.toStringTag, { value: "Module" });
  })((this.markmap.autoLoader = this.markmap.autoLoader || {}));
//# sourceMappingURL=/sm/cb79d9e12dd286ef44083dd3a59fac30ac2469ca168e06859000d602486698a5.map
