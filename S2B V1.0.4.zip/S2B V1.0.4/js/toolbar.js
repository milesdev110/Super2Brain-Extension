/**
 * Minified by jsDelivr using Terser v5.19.2.
 * Original file: /npm/markmap-toolbar@0.17.0/dist/index.js
 *
 * Do NOT use SRI with dynamically generated files! More information: https://www.jsdelivr.com/using-sri-with-dynamic-files
 */
!(function (t) {
  "use strict";
  /*! @gera2ld/jsx-dom v2.2.2 | ISC License */ const A = 1,
    e = 2,
    r = "http://www.w3.org/2000/svg",
    i = "http://www.w3.org/1999/xlink",
    n = { show: i, actuate: i, href: i },
    o = (t) => "string" == typeof t || "number" == typeof t,
    s = (t) => (null == t ? void 0 : t.vtype) === A,
    l = (t) => (null == t ? void 0 : t.vtype) === e;
  function h(t, r) {
    let i;
    if ("string" == typeof t) i = A;
    else {
      if ("function" != typeof t) throw new Error("Invalid VNode type");
      i = e;
    }
    return { vtype: i, type: t, props: r };
  }
  const c = h;
  function a(t) {
    return t.children;
  }
  const g = { isSvg: !1 };
  function v(t, A) {
    Array.isArray(A) || (A = [A]),
      (A = A.filter(Boolean)).length && t.append(...A);
  }
  const u = { className: "class", labelFor: "for" };
  function d(t, A, e, r) {
    if (((A = u[A] || A), !0 === e)) t.setAttribute(A, "");
    else if (!1 === e) t.removeAttribute(A);
    else {
      const i = r ? n[A] : void 0;
      void 0 !== i ? t.setAttributeNS(i, A, e) : t.setAttribute(A, e);
    }
  }
  function m(t, A) {
    return Array.isArray(t)
      ? t.map((t) => m(t, A)).reduce((t, A) => t.concat(A), [])
      : f(t, A);
  }
  function f(t, A = g) {
    if (null == t || "boolean" == typeof t) return null;
    if (t instanceof Node) return t;
    if (l(t)) {
      const { type: e, props: r } = t;
      if (e === a) {
        const t = document.createDocumentFragment();
        if (r.children) {
          v(t, m(r.children, A));
        }
        return t;
      }
      return f(e(r), A);
    }
    if (o(t)) return document.createTextNode(`${t}`);
    if (s(t)) {
      let e;
      const { type: i, props: n } = t;
      if (
        (A.isSvg || "svg" !== i || (A = Object.assign({}, A, { isSvg: !0 })),
        (e = A.isSvg
          ? document.createElementNS(r, i)
          : document.createElement(i)),
        (function (t, A, e) {
          for (const r in A)
            if ("key" !== r && "children" !== r && "ref" !== r)
              if ("dangerouslySetInnerHTML" === r) t.innerHTML = A[r].__html;
              else if (
                "innerHTML" === r ||
                "textContent" === r ||
                "innerText" === r ||
                ("value" === r && ["textarea", "select"].includes(t.tagName))
              ) {
                const e = A[r];
                null != e && (t[r] = e);
              } else
                r.startsWith("on")
                  ? (t[r.toLowerCase()] = A[r])
                  : d(t, r, A[r], e.isSvg);
        })(e, n, A),
        n.children)
      ) {
        let t = A;
        A.isSvg &&
          "foreignObject" === i &&
          (t = Object.assign({}, t, { isSvg: !1 }));
        const r = m(n.children, t);
        null != r && v(e, r);
      }
      const { ref: o } = n;
      return "function" == typeof o && o(e), e;
    }
    throw new Error("mount: Invalid Vnode!");
  }
  function R(t) {
    return f(t);
  }
  const p = "mm-toolbar-item";
  function w({ title: t, content: A, onClick: e }) {
    return h("div", { className: p, title: t, onClick: e, children: A });
  }
  let B;
  const y = class t {
    constructor() {
      (this.showBrand = !0),
        (this.registry = {}),
        (this.el = R(h("div", { className: "mm-toolbar" }))),
        (this.items = [...t.defaultItems]),
        this.register({
          id: "zoomIn",
          title: "Zoom in",
          content: t.icon("M9 5v4h-4v2h4v4h2v-4h4v-2h-4v-4z"),
          onClick: this.getHandler((t) => t.rescale(1.25)),
        }),
        this.register({
          id: "zoomOut",
          title: "Zoom out",
          content: t.icon("M5 9h10v2h-10z"),
          onClick: this.getHandler((t) => t.rescale(0.8)),
        }),
        this.register({
          id: "fit",
          title: "Fit window size",
          content: t.icon(
            "M4 7h2v-2h2v4h-4zM4 13h2v2h2v-4h-4zM16 7h-2v-2h-2v4h4zM16 13h-2v2h-2v-4h4z"
          ),
          onClick: this.getHandler((t) => t.fit()),
        }),
        this.register({
          id: "recurse",
          title: "Toggle recursively",
          content: t.icon("M16 4h-12v12h12v-8h-8v4h2v-2h4v4h-8v-8h10z"),
          onClick: (t) => {
            var A;
            const e = t.target.closest(`.${p}`),
              r = null == e ? void 0 : e.classList.toggle("active");
            null == (A = this.markmap) ||
              A.setOptions({ toggleRecursively: r });
          },
        }),
        this.render();
    }
    static create(A) {
      const e = new t();
      return e.attach(A), e;
    }
    static icon(t, A = {}) {
      return (
        (A = {
          stroke: "none",
          fill: "currentColor",
          "fill-rule": "evenodd",
          ...A,
        }),
        h("svg", {
          width: "20",
          height: "20",
          viewBox: "0 0 20 20",
          children: h("path", { ...A, d: t }),
        })
      );
    }
    setBrand(t) {
      return (this.showBrand = t), this.render();
    }
    register(t) {
      this.registry[t.id] = t;
    }
    getHandler(t) {
      var A;
      return (
        (A = t),
        (t = async (...t) => {
          if (!B) {
            B = A(...t);
            try {
              await B;
            } finally {
              B = void 0;
            }
          }
        }),
        () => {
          this.markmap && t(this.markmap);
        }
      );
    }
    setItems(t) {
      return (this.items = [...t]), this.render();
    }
    attach(t) {
      this.markmap = t;
    }
    render() {
      const t = this.items
        .map((t) => {
          if ("string" == typeof t) {
            const A = this.registry[t];
            return A || console.warn(`[markmap-toolbar] ${t} not found`), A;
          }
          return t;
        })
        .filter(Boolean);
      for (; this.el.firstChild; ) this.el.firstChild.remove();
      return (
        this.el.append(
          R(
            c(a, {
              children: [
                this.showBrand &&
                  c("a", {
                    className: "mm-toolbar-brand",
                    href: "https://markmap.js.org/",
                    children: [
                      h("img", {
                        alt: "markmap",
                        src: "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAMAAABEpIrGAAACoFBMVEUAAAAAAAD//wAAAACAgAD//wAAAABVVQCqqgBAQACAQACAgABmZgBtbQAAAABgQABgYAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAaFQAAAAAAAAAAAAAAAAAHAAARBQIdGAIYEwI/OgJYUQUfHQI+OgJDPgJJRARBPQRJQgRRSwRRTQRIQQRUTgRUUARZUgRSTQRPSQRjWgZORQRfWQZsZAhTTQRNRwRWUAZkXAZOSARUTgZPRwRRSQRoYwZWUQZWTgRbUwZmXQZoXghmXwdqYwdsYwdfVwVmXQdqYgdiWgVpYAl3bgl6cgl4cAqLggw8OAOWjA2Uig1OSAR2bQihlg55cAh5cAh6cQmMgwyOhAyUjA2QhQ2Uiw2Viw2soBCflA+voxGwpRGhlg+hlg+snxGroBGjmBCpnBC0pxKyphKxpRG2qhK0qBK5rBK5rBP/7h3/8B7/8R3/8h3/8R7/8h786x397B3+7R3EtxT66Rz66hz76hz86xz96xz97Bz+7Rz45xz56Bz76hz97Bz97B3MvRX15Rv25Rv45xz66Rz76hz97B3+7R3IuxX05Bv15Bv25Rz56Bz66Ry/sxPAsxPCtRTCthTNvxbZyxfczxfi0xjl1Rnn2Bnr2xrr3Brs3Rru3Rru3xrv3hrw3xrx4Bvx4Rvy4hvz4hvz4xv04xv05Bv14xv15Bv15Rv25Bv25Rv25Rz25hv35hv35xv45xv45xz55xz56Bv56Bz66Rv66Rz76Rv76Rz76hz86hv86xz+7h3/7R3/7h3/7x3/8B3/8B7/8R3/8R4Yqhj5AAAAq3RSTlMAAQECAgIDAwMEBAQFBwgICAwQERITFRYXGBkbHB0eHyQlJyguNTg8RUZISU5PV2FiY2RlZmdqa2xubnJzc3R2d3d3eXl5eXp7fH1+gIGCgoKDg4SEhIWGh4eHiYmJjIyMjZSUlJ+sra+zt7i4uru8ztHV1tbW2d7g4OHi4uPk5ufp7Ozv9fX29/f3+Pj6+vr7+/v7+/v7+/z8/Pz8/f39/f39/f3+/v7+/v7K6J1dAAACHklEQVQ4y2NgwAoYWdi5uLm5GXHIcrLCmMzYpDmAhKCKjoGtp40MFhVsDAwSxmmVEzZu2XvqSLkchjw3g0h445Ybd24vmTN1Usd5X3R5DgaNqgN35sycP2/GxMkTMRVwMOivvtO3YsWUm3duX790EcMKdgbNNXdnnJh1+9T6ipzU+FB0RzIyiFYB5WdfaElUF8TmTQ6GwH39J2bvypMHcpg4MAKKkUGo5s6KWRfyGRh4WJClGEGBCgS8DLobliy/3abMwM8NBYwQjXDgf3ryxOspyKYyg+RFTFwdnYDAzbrw+oLFm9Ot3J3AwNHFTBykQrhg++GDh48cOXzk4P6VZy8s230MyAGCwwcP7iyRBJpiur1n8hQIWHX27NkLi6bAwOSuow5ABeY7OydOhoCFIAULe6E8YFCf8QAqEC86evniZTA4tfLsuRXHr0E4ly9ePF0uC3KnpH1MZBQQxPoVgxyZ5RMdBQaRMc6yIEcihWbQGaA3k9G8CfQoN0pAtSoxCMACihk9qGtBQZ2LHtRIkRUMiqwd2TJADiswsrjQlAGju/o+MLrPNkWo8mFN1ewMWmvBCebQ0rKMJG87QzF0FRwMRuvugpLcrXu3rp7Zs61UCtMZ2nVHbk+fMX/+jMmTp3Sf9MLiULG45q237txaPG3yxPYrYQzYMo60RWbD3E27Ll68Uq+AK+uJqOlZBiSEKGLNnMA0iDfzwrI/NKgBOivk9piPdtUAAAAASUVORK5CYII=",
                      }),
                      h("span", { children: "markmap" }),
                    ],
                  }),
                t.map(w),
              ],
            })
          )
        ),
        this.el
      );
    }
  };
  y.defaultItems = ["zoomIn", "zoomOut", "fit", "recurse"];
  let z = y;
  (t.Toolbar = z),
    Object.defineProperty(t, Symbol.toStringTag, { value: "Module" });
})((this.markmap = this.markmap || {}));
//# sourceMappingURL=/sm/adba47aa401d3315097245499685e39a208052fd8e7a2433d63acf4774545c96.map
